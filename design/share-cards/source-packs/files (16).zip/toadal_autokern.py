#!/usr/bin/env python3
"""
toadal_autokern.py (v2) -- geometry-based pair kerning for the TOADAL lettering engine.

The engine does not draw the raw font outlines: every glyph is "puffed" (gently rounded and
inflated) first.  This tool applies the SAME puffing to every glyph, then for every ordered pair
(A, B) slides B along the baseline until the closest approach between the two PUFFED shapes equals
GAP_EM, and records where B's origin lands relative to A's advance:

    kern(A, B) [em] = (origin_shift(B) - advance(A)) / R

That is the "physics-aware" collision measurement from the concept brief (T tucks over round
neighbours, A closes against L, ...) baked to a lookup table.

Usage (needs Pillow, numpy, scipy; the font must be .ttf/.otf -- convert woff2 with fontTools first):
    python3 toadal_autokern.py path/to/font.ttf [gap_em=0.018] [close=0.010] [round=0.052] [inflate=0.014] > kern.json

The JSON ({chars, gap, rows, median}, units 0.001 em) feeds TOADAL_KERN in the engine. The three puff
numbers MUST match TOADAL_PUFF in the engine, otherwise spacing is measured on different shapes.
"""
import sys, json
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy import ndimage

if len(sys.argv) < 2:
    sys.exit(__doc__)
FONT = sys.argv[1]
GAP_EM   = float(sys.argv[2]) if len(sys.argv) > 2 else 0.018
CLOSE_EM = float(sys.argv[3]) if len(sys.argv) > 3 else 0.010
ROUND_EM = float(sys.argv[4]) if len(sys.argv) > 4 else 0.052
INFL_EM  = float(sys.argv[5]) if len(sys.argv) > 5 else 0.014
CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!?.,:;-'\"&%+/#*()_@$=<>"
R = 400                                   # raster size of 1 em (higher than the engine's sprites; kerning is in em)
CLAMP = (-0.34, 0.20)

font = ImageFont.truetype(FONT, R)

def dil(S, r):  return ndimage.distance_transform_edt(~S) <= r
def ero(S, r):  return ndimage.distance_transform_edt(S) >= r

def puffed(ch):
    """The engine's puffing: closing(c), opening(p') and inflate, with p' limited by the glyph's thickest stroke
    (p' = min(p, 0.80 * Dmax - c)) so thin glyphs (hyphen, quotes ...) can never vanish."""
    M = int(0.16 * R)
    l, t, r, b = font.getbbox(ch, anchor='ls')
    W, H = (r - l) + 2 * M + 4, (b - t) + 2 * M + 4
    ox, oy = M - l + 2, M - t + 2
    im = Image.new('L', (W, H), 0)
    ImageDraw.Draw(im).text((ox, oy), ch, font=font, fill=255, anchor='ls')
    S = np.array(im) >= 128
    c, p, i = CLOSE_EM * R, ROUND_EM * R, INFL_EM * R
    S1 = dil(S, c)
    din = ndimage.distance_transform_edt(S1)
    p_eff = max(0.0, min(p, 0.80 * din.max() - c))
    S3 = din >= (c + p_eff)
    S4 = dil(S3, p_eff + i)
    return S4, ox, oy

# one common canvas: pen origin of A at (X0, BASE); B is shifted by s px
masks, adv, edt, pts = {}, {}, {}, {}
PADW, PADH = 1500, 1200
X0, BASE = 420, 780
def on_canvas(S, ox, oy, shift=0):
    cv = np.zeros((PADH, PADW), bool)
    y0, x0 = BASE - oy, X0 - ox + shift
    h, w = S.shape
    ya, xa = max(0, y0), max(0, x0)
    yb, xb = min(PADH, y0 + h), min(PADW, x0 + w)
    if ya < yb and xa < xb:
        cv[ya:yb, xa:xb] = S[ya - y0:yb - y0, xa - x0:xb - x0]
    return cv

for ch in CHARS:
    S, ox, oy = puffed(ch)
    cv = on_canvas(S, ox, oy)
    masks[ch] = (S, ox, oy)
    adv[ch] = font.getlength(ch)
    edt[ch] = ndimage.distance_transform_edt(~cv)           # distance to glyph A, everywhere
    er = ndimage.binary_erosion(S, iterations=1)
    ys, xs = np.nonzero(S & ~er)
    if len(ys) > 3000:
        sel = np.linspace(0, len(ys) - 1, 3000).astype(int); ys, xs = ys[sel], xs[sel]
    pts[ch] = (ys, xs)                                       # B's boundary pixels (sprite coords)

def mindist(a, b, s):
    """closest distance between puffed A (pen at X0) and puffed B whose pen is s px right of A's pen."""
    S, ox, oy = masks[b]
    ys, xs = pts[b]
    yy = ys - oy + BASE
    xx = xs - ox + X0 + int(round(s))
    ok = (yy >= 0) & (yy < PADH) & (xx >= 0) & (xx < PADW)
    if not ok.any():
        return 1e9
    return float(edt[a][yy[ok], xx[ok]].min())

D = GAP_EM * R
STEP = 6
rows = []
for a in CHARS:
    row = []
    for b in CHARS:
        hi = int(adv[a]) + 300
        while mindist(a, b, hi) < D and hi < 3000: hi += 200      # a valid (far apart) start on the right
        s = hi
        lo_limit = -int(adv[b]) - 400
        while s > lo_limit and mindist(a, b, s - STEP) >= D: s -= STEP   # slide B toward A until contact
        lo, hi2 = s - STEP, s                                              # lo: too close, hi2: clear
        while hi2 - lo > 1:
            mid = (lo + hi2) // 2
            if mindist(a, b, mid) >= D: hi2 = mid
            else: lo = mid
        k = (hi2 - adv[a]) / R
        lo = max(CLAMP[0], -0.55 * min(adv[a], adv[b]) / R)      # never tuck a pair further than ~half of its narrower glyph
        row.append(int(round(max(lo, min(CLAMP[1], k)) * 1000)))
    rows.append(row)

flat = [v for r in rows for v in r]
print("// autokern v2: font=%s gap=%.3f close=%.3f round=%.3f inflate=%.3f chars=%d median=%d (units 0.001em)" %
      (FONT, GAP_EM, CLOSE_EM, ROUND_EM, INFL_EM, len(CHARS), int(np.median(flat))), file=sys.stderr)
print(json.dumps({"chars": CHARS, "gap": GAP_EM, "rows": rows, "median": int(np.median(flat)),
                  "puff": {"close": CLOSE_EM, "round": ROUND_EM, "inflate": INFL_EM}}))
